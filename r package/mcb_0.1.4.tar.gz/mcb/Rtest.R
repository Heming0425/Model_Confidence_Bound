# test script

library(mcb)

data(Diabetes) # load data
x <- Diabetes[,c('S1','S2','S3','S4','S5','S6')]
y <- Diabetes[,c('Y')]
x <- data.matrix(x)
y <- data.matrix(y)

# test 1
re1 <- mcb.compare(x, y, methods = c("aLasso","Lasso"))
re2 <- mcb.compare(x, y, methods = c("aLasso","Lasso"), ufull = TRUE)
mucplot(re1)
mucplot(re2)

# test2
re3 <- mcb(x, y, method = c("aLasso"))
re4 <- mcb(x, y, method = c("Lasso"), ufull = TRUE)
mucplot(re3)
mucplot(re4)

rvData <- read.csv("rv.csv")
xRV <- rvData[,c("J","C","SJ","TC","TJ","BPV","RS.","ΔJ")]
yRV <- rvData[,c("RV")]
xRV <- data.matrix(xRV)
yRV <- data.matrix(yRV)

# test 3
re5 <- mcb.compare(x, y, methods = c("LAD","SQRT"))
re6 <- mcb.compare(x, y, methods = c("LAD","SQRT"), ufull = TRUE)
mucplot(re5)
mucplot(re6)

# test4
re7 <- mcb(x, y, method = c("LAD"))
re8 <- mcb(x, y, method = c("SQRT"), ufull = TRUE)
mucplot(re7)
mucplot(re8)
