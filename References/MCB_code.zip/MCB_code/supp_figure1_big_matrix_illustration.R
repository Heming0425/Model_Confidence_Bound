###################################
# The function to generate Figure 1 in the supplementary
# You can change the parameter setting to get different figures
###################################
library(gplots)
set.seed(123456)
source("functions.R")
##parameters setting
size=150;p=10;true.mean=0;true.sd=1;decay.factor=1;sd.epsi=3;rho=0;dep.var.index=p+1;r=100;s=1;confidence_level=0.8;num_true_var=3
full.var<-paste("x",1:p,sep="")
test.data<-Generate.Data(size,p,true.mean,true.sd,decay.factor,sd.epsi,rho,num_true_var)
var.instances <- RES.BOOT.CI(test.data,dep.var.index,r,s=1)
var.01<-f01(var.instances)###0-1 matrix
result<-CI(var.instances,var.01,p)

ci_lower<-result$lower
ci_upper<-result$upper
lower_bound<-ci_lower[which(result$freq>confidence_level)[1]]
upper_bound<-ci_upper[which(result$freq>confidence_level)[1]]
lower_bound<-f01(lower_bound)
upper_bound<-f01(upper_bound)

lower_part <- data.frame(matrix(nrow = 0, ncol = p))
middle_part <- data.frame(matrix(ncol = p, nrow = 0))
upper_part <- data.frame(matrix(ncol = p, nrow = 0))
var_order <- order(apply(var.01,2,sum), decreasing = TRUE)
col_name <- paste("x",var_order, sep = '')
colnames(middle_part) <- col_name
colnames(lower_part) <- col_name
colnames(upper_part) <- col_name
#generate_plot_matrix <- function(){
  for (i in 1:r){
  single_model <- var.01[i,][var_order]
  single_model_name <- colnames(single_model)[single_model == 1]
  if (all(all(f03(lower_bound)%in%single_model_name), all(single_model_name%in%f03(upper_bound)))){
    middle_part <- model_ranking(middle_part, single_model)
  } else {
    if (all(!all(single_model_name%in%f03(upper_bound)), all(f03(lower_bound)%in%single_model_name))){
      upper_part <- model_ranking(upper_part, single_model)
    } else {
      lower_part <- model_ranking(lower_part, single_model)
    }
  }
  }
  plot_matrix <- rbind(lower_part, middle_part, upper_part)
#  return(plot_matrix)
#}

plot(rep(1,p) - 0.5, y = c(1:p) , xlim = c(1,r), ylim = c(1,p) ,pch = 22, bg = gray(1 - plot_matrix[1,]), cex = 0.7, yaxt = 'n', xlab = 'Boostrap Models', ylab = 'Variable', main = 'Illustration2')
axis(side = 2,at=c(1:p),labels=col_name,cex.axis=1, las = 2)
mtext(apply(var.01,2,sum)[var_order], side = 2, line = 2.2, at = c(1:p), cex = 1)
for (i in c(2:r)){
  points(rep(i,p) - 0.5, c(1:p), pch = 22, bg = gray(1 - plot_matrix[i,]), cex = 0.7)
}
abline(v = dim(lower_part)[1])
abline(v = (dim(lower_part)[1] + dim(middle_part)[1]))
abline(h = sum(lower_bound) + 0.5)
abline(h = sum(upper_bound) + 0.5)

# heatmap plot
plot.matrix <- data.matrix(plot_matrix)
par(mar=c(2,2,0.2,2))
rownames(plot.matrix) <- NULL
heatmap.2(plot.matrix,Rowv=NULL, dendrogram='none',labRow = FALSE,srtCol = 360 ,col=colorpanel(7, "white", "grey10"),Colv=NULL, revC=FALSE, scale="none",key=FALSE,density.info="none", trace="none", ylab='Boostrap Models',las = 1,cexRow = 8,cexCol = 2,cex.lab = 10,
          colsep=c(1:dim(plot_matrix)[2]) , rowsep = c(1:dim(plot_matrix)[1]),ColSideColors = c(rep('red',sum(lower_bound)),rep('blue',sum(upper_bound)-sum(lower_bound)),rep('white',p - sum(upper_bound))),RowSideColors = c(rep('green',dim(lower_part)[1]),rep('purple',dim(middle_part)[1]),rep('brown',dim(upper_part)[1])),sepcolor = 'gray', sepwidth = c(0.00005,0.00005),lhei = c(1.6,8),lwid = c(0.5,8),margins = c(5,3))
mtext(apply(var.01,2,sum)[var_order], side = 1, line = 0.05, at = seq(from=3,to=106,by=10.4), cex = 1.5)
legend("topright",legend = c('LBM','UBM - LBM'),fill = c('red','blue'),bty = 'n', border = FALSE,cex = 1.5,text.width = 20)
legend("topleft",legend = c('Underfitting models', 'Models in MCBs','Overfitting models'),fill = c('green','purple','brown'),bty = 'n', border = FALSE,cex = 1.5,text.width = 0.1)

abline(h = 2.33, col = 5)
abline(h = 8.37, col = 5)


