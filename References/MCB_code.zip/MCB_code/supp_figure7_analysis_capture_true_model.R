###################################
# The function to generate Figure 7 in the supplementary
# You can change the parameter setting to get different figures
###################################
set.seed(123456)
source("functions.R")
ptm <- proc.time()
size=100;p=20;true.mean=0;true.sd=1;decay.factor=1;sd.epsi=1;rho=0;dep.var.index=p+1;r=300;s=100;num_true_var=6;cores_num=3;num_lambda=20
model_type=1
lambda_search_method = 1 # 1 means search for the all range, 0 means search for with smaller area
search_start = 0.153
search_end = 0.267
if (lambda_search_method == 0){
	lambda_search_start <- search_start
	lambda_search_end <- search_end
}
true.model<-paste("x",1:num_true_var,sep="")
true.model_vector <- vector('numeric', length = p)
true.model_vector[1:num_true_var] <- 1
full.var<-paste("x",1:p,sep="")
whole.data<-vector(length=s,mode='list')

MCB_results_matrix <- NULL

if (lambda_search_method == 1){
	test.data <- Generate.Data(size,p,true.mean,true.sd,decay.factor,sd.epsi,rho, num_true_var, model_type)
	simple_lasso <- glmnet(as.matrix(test.data[, 1:p]), test.data$y, family='gaussian', alpha=1)
	all_candidate_lambda <- simple_lasso$lambda
	candidate_lambda <- all_candidate_lambda[c(round(seq(1, length(all_candidate_lambda)/3, length.out = num_lambda/2)),round(seq(length(all_candidate_lambda)/3 + 1, 2*length(all_candidate_lambda)/3, length.out = num_lambda/4)),round(seq(2*length(all_candidate_lambda)/3 + 1, length(all_candidate_lambda), length.out = num_lambda/4)))] 
} else{
	candidate_lambda <- seq(lambda_search_start, lambda_search_end, length.out = num_lambda)
}

for (i in 1:s)
{
  whole.data[[i]]<-Generate.Data(size,p,true.mean,true.sd,decay.factor,sd.epsi,rho, num_true_var, model_type)
}
RNGkind("L'Ecuyer-CMRG")
results<-mclapply(whole.data,function(data)captrue_model(data, p + 1, r, candidate_lambda),mc.cores=cores_num)
truecapmatrix <- sapply(results, function(result) result$truecapture)
MCB_capture_matrix <- sapply(results, function(result) result$freq)
truecap_result <- matrix(apply(truecapmatrix, 1 , mean), nrow = length(candidate_lambda))
MCBcap_result <- matrix(apply(MCB_capture_matrix, 1 , mean), nrow = length(candidate_lambda))

truecap_result <- cbind(candidate_lambda, truecap_result)
MCBcap_result <- cbind(candidate_lambda, MCBcap_result)


MCB_file_name <- paste("cap_true_analysis_MCB", 'size', size, 'p', p, 'rho', rho,"sd", sd.epsi, "decay",decay.factor, "tol_iter", s , "boot_time", r, "num_tru", num_true_var,"num_lambda", num_lambda, 'model_type', model_type, 'lambda_search_method', lambda_search_method,sep = "_")
write.csv(MCBcap_result, file = paste("../MCB_results/",MCB_file_name, ".csv", sep = ""))
true_cap_file_name <- paste("cap_true_analysis_cap_true", 'size', size, 'p', p, 'rho', rho,"sd", sd.epsi, "decay",decay.factor, "tol_iter", s , "boot_time", r, "num_tru", num_true_var, "num_lambda", num_lambda, 'model_type', model_type, 'lambda_search_method', lambda_search_method,sep = "_")
write.csv(truecap_result, file = paste("../MCB_results/",true_cap_file_name, ".csv", sep = ""))


# plotmatrix<-cbind(c(0:p),captrue,cicapture)

# min_max_diff <- 1
# diff_start <- sum(abs(MCBcap_result[1,2:(p+2)] - truecap_result[1,2:(p+2)])^2)
# for (i in 2:length(candidate_lambda)){
# 	diff <- sum(abs(MCBcap_result[i,2:(p+2)] - truecap_result[i,2:(p+2)])^2)
# 	if (diff < diff_start) min_max_diff <- i
# 	diff_start <- diff
# }

#PLOT1: PLOT BCR and TRUE MODEL COVERAGE RATE
MCBcap_result <- read.csv(paste(MCB_file_name, '.csv', sep = ""), header = T)
truecap_result <- read.csv(paste(true_cap_file_name, '.csv', sep = ""), header = T)
par(mar=c(4.5,4.7,1,1))
cexnum=2.5

plot(x=c(0:p)/p,y=truecap_result[6,3:(p+3)],lty=1,lwd=3,col=1,cex=cexnum,cex.axis=2.5,cex.lab=cexnum,xlim=c(0,1),type='l',ylim=c(0,1),xlab='w/p',ylab='Coverage Rate')
lines(x= c(0:p)/p,y=MCBcap_result[6,3:(p+3)],lty=1,lwd=3,col=2,xlim=c(0,1),type='l',ylim=c(0,1))
legend('bottomright',legend = c('TMUC','MUC'),col=c(1,2),lwd=rep(3,2),text.width =0.3,cex = cexnum,pt.cex = cexnum)
file_name <- paste("analysis_capture_true_model","size",size,"sd", sd.epsi, "num_tol", p, "num_true", num_true_var, "decay",decay.factor, "tol_iter", s , "boot_time", r,sep = "_")
save.image(file = paste("../MCB_results/",file_name, ".RData", sep = ""))

plot(x=c(0:p)/p,y=plotmatrix[,2],lty=1,lwd=3,col=1,cex=cexnum,cex.axis=2.5,cex.lab=cexnum,xlim=c(0,1),type='l',ylim=c(0,1),xlab='w/p',ylab='Coverage Rate')
lines(x= c(0:p)/p,y=plotmatrix[,3],lty=1,lwd=3,xlim=c(0,1),type='b', pch = 1,ylim=c(0,1))
legend('bottomright',legend = c('TMUC','MUC'),pch = c(NA, 1),lwd=rep(3,2),text.width =0.3,cex = cexnum,pt.cex = cexnum)

# print out processing time and parameter setting 
processing_time <- proc.time() - ptm
proc.time() - ptm
