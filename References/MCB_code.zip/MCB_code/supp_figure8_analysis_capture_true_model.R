library(MASS)
library(Matrix)
library(glmnet)
set.seed(1234)

# Generate Data
Generate.Data.Lasso<-function(size,p,sig.num,sd.epsi,rho)
{
  ########################################################multinominal correlated simulation
  omiga<-matrix(0,nrow=p,ncol=p)
  for(i in 1:p)
  {
    for(j in 1:p)
    {
      omiga[i,j]<-rho^(abs(i-j))
    }
  }
  data<-mvrnorm(n=size,mu=rep(0,p),omiga)
  colnames(data)=paste("x",1:p,sep="")
  u<-rnorm(size, 0, sd.epsi)
  
  b<-matrix(1,nrow=sig.num,ncol=1)
  y<-data[,1:sig.num]%*%b+u
  
  colnames(y)=c('y')
  return(data.frame(data,y))
}

# MCBs under different widths
CI<-function(var.matrix)
{
  colsum<-apply(var.matrix,2,sum)
  order<-order(colsum,decreasing = T)
  freq<-vector(length=p+1);freq[1]<-0
  lower<-matrix(0,nrow=(p+1),ncol=p)
  upper<-matrix(0,nrow=(p+1),ncol=p)
  for(i in 0:p)##########i is the length of MCI
  {
    cap<-vector(length=p-i+1);cap[1]<-0
    for(j in 0:(p-i))##########j is the length of lowerbound
    {
      if(j==0 && i==0){
        lowtest<-rep(0,p)
        upptest<-rep(0,p)
      }else{
        if(j==0 && i!=0){
          lowtest<-rep(0,p)
          upptest<-rep(0,p)
          upptest[order[1:i]]<-1
        }else{
          lowtest<-rep(0,p)
          upptest<-rep(0,p)
          lowtest[order[1:j]]<-1
          upptest[order[1:(i+j)]]<-1
        }
      }
      for(m in 1:r){
        if(all(all(lowtest<=var.matrix[m,]),all(var.matrix[m,]<=upptest))) cap[j+1]<-cap[j+1]+1
      }
    }
    freq[i+1]<-max(cap)/r
    maxlocation<-which.max(cap)
    if(i==0 && maxlocation==1)
    {
      lower[i+1,]<-rep(0,p)
      upper[i+1,]<-rep(0,p)
    }else{
      if(maxlocation==1 && i!=0){
        lower[i+1,]<-rep(0,p)
        upper[i+1,order[1:i]]<-1
      }else{
        lower[i+1,order[1:(maxlocation-1)]]<-1
        upper[i+1,order[1:(maxlocation-1+i)]]<-1
      }
    }
  }
  
  result<-list(freq=freq,lower=lower,upper=upper)
  return(result)
}

# Computing coverage rate
captrue_model<-function(data_total)
{
  # Adalasso Original Dataset(specified lambda)
  tau<-1
  lasso.init<-glmnet(as.matrix(data_total[,1:p]),data_total$y)
  first.step.coef<-lasso.init$beta[,which.min(abs(lasso.init$lambda-lmbd))]
  penalty.factor<-abs(first.step.coef+1/sqrt(nrow(data_total)))^(-tau)
  adalasso<-glmnet(as.matrix(data_total[,1:p]),data_total$y,penalty.factor=penalty.factor)
  beta.adalasso<-matrix(unname(adalasso$beta[,which.min(abs(adalasso$lambda-lmbd))]),1,p)
  res.adalasso<-data_total$y-as.matrix(data_total[,1:p])%*%t(beta.adalasso)
  res.adalasso.center<-res.adalasso-mean(res.adalasso)
  constant<-as.matrix(data_total[,1:p])%*%t(beta.adalasso)
  
  # Residual Boostrap
  var.01<-matrix(0,nrow=r,ncol=p)
  for(j in 1:r) { 
    boot_res<-sample(res.adalasso.center,size,replace=T)
    boot_y<-constant+boot_res
    boot.data<-data.frame(data_total[,1:p],boot_y)
    ##################variable selection method: Adaptive Lasso
    lasso.init.boot<-glmnet(as.matrix(boot.data[,1:p]),boot.data$boot_y)
    first.step.coef.boot<-lasso.init.boot$beta[,which.min(abs(lasso.init.boot$lambda-lmbd))]
    penalty.factor.boot<-abs(first.step.coef.boot+1/sqrt(nrow(data_total)))^(-tau)
    adalasso.boot<-glmnet(as.matrix(boot.data[,1:p]),boot.data$boot_y,penalty.factor=penalty.factor.boot)
    beta.adalasso.boot<-adalasso.boot$beta[,which.min(abs(adalasso.boot$lambda-lmbd))]
    var.01[j,]<-full.var%in%full.var[beta.adalasso.boot!=0]
  }
  
  cap_ture<-function(low_list,upper_list){
    truecapture<-vector()# true model in mcbs under different widths
    for(i in 1:(p+1))
    {
      if(all(all(low_list[i,]<=true.model),all(true.model<=upper_list[i,]))) truecapture[i]<-1 else truecapture[i]<-0
    }
    return(truecapture)
  }
  result<-CI(var.01)
  lower<-result$lower
  upper<-result$upper
  freq<-result$freq
  truecapture<-cap_ture(lower,upper)
  results<-list(freq=freq,truecapture=truecapture,lower=lower,upper=upper)
  return(results)
}


# Parameter settings
size=100;p=10;sig.num=5;sd.epsi=6;r=200;alpha=0.05;s=100
rho=0.75
lmbd=0.25
full.var<-paste("x",1:p,sep="")

# True Model
true.model<-rep(0,p)
true.model[1:sig.num]<-1

whole.data<-vector(length=s,mode='list')
for (i in 1:s)
{
  whole.data[[i]]<-Generate.Data.Lasso(size,p, sig.num, sd.epsi,rho)
}

results<-lapply(whole.data,function(data)captrue_model(data))

# MUC and TMUC curves
truecapmatrix.adalasso<-NULL
cimatrix.adalasso<-NULL
for(i in 1:length(results))
{
  truecapmatrix.adalasso<-rbind(truecapmatrix.adalasso,results[[i]]$truecapture)
  cimatrix.adalasso<-cbind(cimatrix.adalasso,results[[i]]$freq)
}
captrue.adalasso<-apply(truecapmatrix.adalasso,2,mean,na.rm=T)#TCR
cicapture.adalasso<-apply(cimatrix.adalasso,1,mean,na.rm=T)#BCR: mean of one round BCR？
plotmatrix.adalasso<-cbind(seq(0,p,1),captrue.adalasso,cicapture.adalasso)

dev.new(width=4,height=4)
par(mar=c(4.5,4.7,1,1))
cexnum=2.5
plot(x=plotmatrix.adalasso[,1]/p,y=plotmatrix.adalasso[,2],lty=1,lwd=3,cex=cexnum,cex.axis=2.5,cex.lab=cexnum,xlim=c(0,1),type='l',ylim=c(0,1),xlab='w/p',ylab='Coverage Rate')
lines(plotmatrix.adalasso[,1]/p,plotmatrix.adalasso[,3],lty=1,lwd=3,xlim=c(0,1),type='b',pch=1,ylim=c(0,1))
legend('topleft',legend = c('TMUC','MUC'),lwd=rep(3,2), pch = c(NA, 1), text.width =0.3,cex = cexnum, pt.cex = cexnum)



