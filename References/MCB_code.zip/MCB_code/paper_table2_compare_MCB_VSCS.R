library(parallel)
library(MASS)
library(glmnet)
source('paper_table2_VSCS_support_functions.R', echo=T)

# Generate Data
GenerateData<-function(size,p,sig.num,sd.epsi,rho)
{
  ########################################################multinominal correlated simulation
  omiga<-matrix(0,nrow=p,ncol=p)
  for(i in 1:p)
  {
    for(j in 1:p)
    {
      omiga[i,j]<-rho^(abs(i-j))
    }
  }
  data<-mvrnorm(n=size,mu=rep(0,p),omiga)
  colnames(data)=paste("x",1:p,sep="")
  u<-runif(size,-sqrt(3)*sd.epsi,sqrt(3)*sd.epsi)
  
  b<-matrix(1,nrow=sig.num,ncol=1)
  y<-data[,1:sig.num]%*%b+u
  colnames(y)=c('y')
  return(data.frame(data,y))
}

# MCBs under different widths
CI<-function(var.matrix)
{
  colsum<-apply(var.matrix,2,sum)
  order<-order(colsum,decreasing = T)
  freq<-vector(length=p+1);freq[1]<-0
  lower<-matrix(0,nrow=(p+1),ncol=p)
  upper<-matrix(0,nrow=(p+1),ncol=p)
  for(i in 0:p)##########i is the length of MCI
  { 
    cap<-vector(length=p-i+1);cap[1]<-0  
    for(j in 0:(p-i))##########j is the length of lowerbound
    {
      if(j==0 && i==0){
        lowtest<-rep(0,p)
        upptest<-rep(0,p)
      }else{
        if(j==0 && i!=0){
          lowtest<-rep(0,p)
          upptest<-rep(0,p)
          upptest[order[1:i]]<-1
        }else{
          lowtest<-rep(0,p)
          upptest<-rep(0,p)
          lowtest[order[1:j]]<-1
          upptest[order[1:(i+j)]]<-1
        }
      }
      for(m in 1:r){
        if(all(all(lowtest<=var.matrix[m,]),all(var.matrix[m,]<=upptest))) cap[j+1]<-cap[j+1]+1
      }
    }  
    freq[i+1]<-max(cap)/r
    maxlocation<-which.max(cap)
    if(i==0 && maxlocation==1)
    {
      lower[i+1,]<-rep(0,p)
      upper[i+1,]<-rep(0,p)
    }else{
      if(maxlocation==1 && i!=0){
        lower[i+1,]<-rep(0,p)
        upper[i+1,order[1:i]]<-1
      }else{
        lower[i+1,order[1:(maxlocation-1)]]<-1
        upper[i+1,order[1:(maxlocation-1+i)]]<-1
      }
    }
  }
  
  result<-list(freq=freq,lower=lower,upper=upper)
  return(result)
}

# Get results
getResults<-function(data_total){
  
  # Adalasso Original Dataset(specified lambda)
  tau<-1
  lasso.init<-glmnet(as.matrix(data_total[,1:p]),data_total$y)
  first.step.coef<-lasso.init$beta[,which.min(abs(lasso.init$lambda-lmbd))] 
  penalty.factor<-abs(first.step.coef+1/sqrt(nrow(data_total)))^(-tau) 
  adalasso<-glmnet(as.matrix(data_total[,1:p]),data_total$y,penalty.factor=penalty.factor)
  beta.adalasso<-matrix(unname(adalasso$beta[,which.min(abs(adalasso$lambda-lmbd))]),1,p)
  res.adalasso<-data_total$y-as.matrix(data_total[,1:p])%*%t(beta.adalasso)
  res.adalasso.center<-res.adalasso-mean(res.adalasso)
  constant<-as.matrix(data_total[,1:p])%*%t(beta.adalasso)
  
  # Residual Boostrap
  var.01<-matrix(0,nrow=r,ncol=p)
  for(j in 1:r) { 
    boot_res<-sample(res.adalasso.center,size,replace=T)
    boot_y<-constant+boot_res
    boot.data<-data.frame(data_total[,1:p],boot_y)
    ##################variable selection method: Adaptive Lasso
    lasso.init.boot<-glmnet(as.matrix(boot.data[,1:p]),boot.data$boot_y)
    first.step.coef.boot<-lasso.init.boot$beta[,which.min(abs(lasso.init.boot$lambda-lmbd))]
    penalty.factor.boot<-abs(first.step.coef.boot+1/sqrt(nrow(data_total)))^(-tau)
    adalasso.boot<-glmnet(as.matrix(boot.data[,1:p]),boot.data$boot_y,penalty.factor=penalty.factor.boot)
    beta.adalasso.boot<-adalasso.boot$beta[,which.min(abs(adalasso.boot$lambda-lmbd))]
    var.01[j,]<-full.var%in%full.var[beta.adalasso.boot!=0]
  }
  
  # Get optimal MCBs 
  getOptimalMCBs<-function(cican, confidence.level){
    fit.index<-which(cican$freq >= confidence.level)
    optimal.mcbs.lower<-cican$lower[min(fit.index),]
    optimal.mcbs.upper<-cican$upper[min(fit.index),]
    optimal.width<-min(fit.index)-1
    result<-list(width=optimal.width, mcb.lower=optimal.mcbs.lower, mcb.upper=optimal.mcbs.upper)
    return(result)
  }
  
  # Get VSCS
  y<-data_total$y
  data_total_vscs<-cbind(y,data_total[1:p])
  getVSCS<-ecs(full.data=data_total_vscs, full.family="gaussian")

  # Computing width, coverage rates and cardinality
  confidence.level<-seq(0.6,0.95,0.05)
  opt.width<-c()
  opt.lower<-matrix(0,nrow=length(confidence.level),ncol=p)
  opt.upper<-matrix(0,nrow=length(confidence.level),ncol=p)
  getOptMCB<-vector(length=length(confidence.level),mode='list')
  card.mcb<-c()
  VSCS.val<-vector(length=length(confidence.level),mode='list')
  card.vscs<-c()
  truecapture.mcb<-c()
  truecapture.vscs<-c()
  
  for(li in 1:length(confidence.level)){
    
    getOptMCB[[li]]<-getOptimalMCBs(CI(var.01), confidence.level[li])
    opt.width[li]<-getOptMCB[[li]]$width
    opt.lower[li,]<-getOptMCB[[li]]$mcb.lower
    opt.upper[li,]<-getOptMCB[[li]]$mcb.upper
    
    # cardinality of MCB
    card.mcb[li]<-2^(opt.width[li])
    
    # Identify the true model in MCBs
    if(all(all(opt.lower[li,]<=true.model),all(true.model<=opt.upper[li,]))){
      truecapture.mcb[li]<-1
    }else{
      truecapture.mcb[li]<-0
    }
    
    # VSCS
    VSCS.val[[li]]<-getVSCS[[li+1]]
    
    # cardinality of VSCS
    if(is.null(nrow(VSCS.val[[li]]))){
      card.vscs[li]<-1
      truecapture.vscs[li]<-0

    }else{
      card.vscs[li]<-nrow(VSCS.val[[li]])
      
      # Identify the true model in VSCS
      if(sum(apply(VSCS.val[[li]],1,function(data) all(data==true.model)))>=1){
        truecapture.vscs[li]<-1
      }else{
        truecapture.vscs[li]<-0
      }
    }
  }
  
  results<-list(optwidth=opt.width, optlower=opt.lower, optupper=opt.upper, truecap.mcb=truecapture.mcb,
                truecap.vscs=truecapture.vscs, cardinality.mcb=card.mcb, cardinality.vscs=card.vscs)
  return(results)
}

# Parameter settings
size=100;p=10;sig.num=5;sd.epsi=2;rho=0;r=1000;s=500
lmbd=0.44

full.var<-paste("x",1:p,sep="")
whole.data<-vector(length=s,mode='list')
for (i in 1:s)
{
  whole.data[[i]]<-GenerateData(size,p, sig.num, sd.epsi,rho)
}

# True Model
true.model<-rep(0,p)
true.model[1:sig.num]<-1

# Parallel(for Linux)
RNGkind("L'Ecuyer-CMRG")
timetotal<-system.time(results<-mclapply(whole.data,function(data)getResults(data),mc.cores=5))

# Results
optwidth.matrix<-NULL
truecap.mcb.matrix<-NULL
cardinality.mcb.matrix<-NULL
truecap.vscs.matrix<-NULL
cardinality.vscs.matrix<-NULL
for(i in 1:length(results)){
  optwidth.matrix<-rbind(optwidth.matrix,results[[i]]$optwidth)
  truecap.mcb.matrix<-rbind(truecap.mcb.matrix,results[[i]]$truecap.mcb)
  cardinality.mcb.matrix<-rbind(cardinality.mcb.matrix,results[[i]]$cardinality.mcb)
  truecap.vscs.matrix<-rbind(truecap.vscs.matrix,results[[i]]$truecap.vscs)
  cardinality.vscs.matrix<-rbind(cardinality.vscs.matrix,results[[i]]$cardinality.vscs)
}

ave.width<-apply(optwidth.matrix,2,mean)
ave.truecap.mcb<-apply(truecap.mcb.matrix,2,mean)
ave.cardinality.mcb<-apply(cardinality.mcb.matrix,2,mean)
ave.truecap.vscs<-apply(truecap.vscs.matrix,2,mean)
ave.cardinality.vscs<-apply(cardinality.vscs.matrix,2,mean)
table.res<-rbind(ave.truecap.vscs,ave.truecap.mcb,ave.cardinality.vscs,ave.cardinality.mcb,ave.width)

save.image("sim_vscs_mcb.RData")

