###################################
# The function to generate Figure 3 in the paper and Figure 4 in the supplementary
# You can change the parameter setting to get different figures
###################################
ptm <- proc.time()
source("functions.R")
set.seed(123456) 
##parameters setting
size=300;p=200;true.mean=0;true.sd=1;decay.factor=1;sd.epsi=1;rho=0.5;dep.var.index=p+1;model_type=1;var_dis = 'normal'
r=1000;s=1;df=3;num_true_var=12
test.data<-Generate.Data(size,p,true.mean,true.sd,decay.factor,sd.epsi,rho,num_true_var = num_true_var, model_type=model_type, var_dis=var_dis)

full.var<-paste("x",1:p,sep="")
tgeneratedata<-system.time(var.instances<-RES.BOOT.CI(test.data,dep.var.index,r))
var.01<-f01(var.instances)###0-1 matrix
ordertime<-system.time(result<-CI(var.instances,var.01,p))
colsum<-apply(var.01,2,sum)
order<-order(colsum,decreasing = T)
print(result$freq)

# NOTE: for p > 15, we only use algorithm 2 to calculate MCBs
if (p > 15){
	cexnum = 2.5
	par(mar=c(4.6,4.8,1,1))
	plot(c(0,seq(from=p/10,to=p,by=p/10)/p),result$freq[c(1,seq(from=p/10,to=p,by=p/10))],xlim=c(0,1),cex=cexnum,cex.axis=cexnum,cex.lab=cexnum,type='b',pch=3,ylim=c(0,1),lty=1,lwd=2,xlab='w/p',ylab = 'Coverage Rate')
}

if (p <= 15){
	upcap<-vector()
	toptup<-system.time(for(k in 1:(p-1))
	{
	  varmatrix<-var.f(k)
	  upcap[k]<-f2(varmatrix,var.instances)
	})

	cioptimaltime<-system.time(cap_res<-cioptimal(var.instances, p))
	cap_res<-cbind(cap_res,c(0,upcap))
	#to compensate the problem of that in origanal order method, we don't consider the case that the lower bound is empty
	cap_res<-apply(cap_res,1,max)
	cimatrix<-data.frame()
	cimatrix<-cbind(c(0:p),result$freq,c(cap_res,1))
	colnames(cimatrix)<-c('width','Algorithm2','Algorithm1')
	par(mar=c(4.6,4.8,1,1))
	cexnum=2.5
	picture<-function(m){
	  plot(m[,1][complete.cases(m[,3])]/p,na.omit(m[,3]),xlim=c(0,1),cex=cexnum,cex.axis=cexnum,pch=cexnum,cex.lab=cexnum,type='b',ylim=c(0,1),lty=1,lwd=2,xlab='w/p',ylab = 'Coverage Rate')
	  lines(m[,1][complete.cases(m[,2])]/p,type='b',na.omit(m[,2]),pch=3,lwd=2,cex=cexnum)
	  legend('bottomright',legend=c("Algorithm1","Algorithm2"),lty=c(1,1),pch=c(2,3),text.width = 0.4,lwd=rep(2,2),cex = cexnum,pt.cex = cexnum)
	}
	picture(cimatrix)
}

file_name <- paste("compare_algo1_algo2","size",size,"sd", sd.epsi, "rho", rho, "num_tol", p, "num_true", num_true_var, "decay", decay.factor, "boot_time", r,sep = "_")
save.image(file = paste("../MCB_results/",file_name, ".RData", sep = ""))

# print out processing time and parameter setting 
# proc.time() - ptm
# processing_time <- proc.time() - ptm
# file_name
# ordertime
# cioptimaltime





