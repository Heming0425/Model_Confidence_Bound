###################################
# The function to generate Figure 4 in the paper
# You can change the parameter setting to get different figures
###################################
library(flare)
library(smoothmest)
set.seed(123456)
source('functions.R')
ptm <- proc.time()
size=300;p=12;true.mean=0;true.sd=1;decay.factor=1;sd.epsi=1;rho=0.5;dep.var.index=p+1;r=500;num_true_var=5;var_dis = 'normal'
model_type=1; thrhd=0.05;
test.data<-Generate.Data(size,p,true.mean,true.sd,decay.factor,sd.epsi,rho, num_true_var, model_type, var_dis)

full.var<-paste("x",1:p,sep="")

var_adaptivelasso <- RES.BOOT.CI(test.data, p + 1, r)
var_lasso <- BOOT.MODI.LASSO(test.data, p + 1, r, thrhd)
var_SCAD <- RES.BOOT.CI3(test.data, p + 1, r, 'SCAD')
var_MCP <- RES.BOOT.CI3(test.data, p + 1, r, 'MCP')
var_stepwise <- RES.BOOT.CI5(test.data, p, r)
var_LAD <- vector(length = 5, mode = 'list')
var_SQRT <- vector(length = 5, mode = 'list')
var_01_LAD <- vector(length = 5, mode = 'list')
var_01_SQRT <- vector(length = 5, mode = 'list')
result_LAD <- vector(length = 5, mode = 'list')
result_SQRT <- vector(length = 5, mode = 'list')

for (i in 1:5){
  var_LAD[[i]] <- RES.BOOT.CI4(test.data, p+1, r, q = 1, beta_index = i)
  var_SQRT[[i]] <- RES.BOOT.CI4(test.data, p+1, r, q = 2, beta_index = i)
  var_01_LAD[[i]] <- f01(var_LAD[[i]])
  var_01_SQRT[[i]] <- f01(var_SQRT[[i]])
  result_LAD[[i]] <- CI(var_LAD[[i]], var_01_LAD[[i]], p)
  result_SQRT[[i]] <- CI(var_SQRT[[i]], var_01_SQRT[[i]], p)
}


var_01_ada_lasso<-f01(var_adaptivelasso)
var_01_lasso<-f01(var_lasso)
var_01_SCAD<-f01(var_SCAD)
var_01_MCP<-f01(var_MCP)
var_01_stepwise <- f01(var_stepwise)

result_adalasso <- CI(var_adaptivelasso, var_01_ada_lasso, p)
result_lasso <- CI(var_lasso, var_01_lasso, p)
result_SCAD <- CI(var_SCAD, var_01_SCAD, p)
result_MCP <- CI(var_MCP, var_01_MCP, p)
result_stepwise <- CI(var_stepwise, var_01_stepwise, p)

final_result <- cbind(result_adalasso$freq, result_lasso$freq, result_SCAD$freq, result_MCP$freq)
colnames(final_result) <- c('adalasso', 'lasso', 'SCAD', 'MCP')

file_name <- paste("compare_model_selection_method","size",size,"sd", sd.epsi, "rho", rho, "num_tol", p, "num_true", num_true_var, "decay", decay.factor, "boot_time", r, 'sd_distri', var_dis,sep = "_")
save.image(file = paste("../MCB_results/",file_name, ".RData", sep = ""))

#print out processing time and parameter setting 
proc.time() - ptm
processing_time <- proc.time() - ptm
print(file_name)
# print(final_result)


pdf(file='rho0_norm.pdf', width=8, height=8)

par(mar=c(4.2,4.4,1,1))
cexnum=1.8

model_selection_method_plot_function(var_dis)

dev.off()