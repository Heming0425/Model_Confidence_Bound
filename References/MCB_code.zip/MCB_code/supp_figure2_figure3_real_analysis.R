## MCB based on different methods using TCGA lung squamous carcinoma data
library(MASS)
library(Matrix)
library(glmnet)

# MCBs under different widths
CI<-function(var.matrix)
{
  colsum<-apply(var.matrix,2,sum)
  order<-order(colsum,decreasing = T)
  freq<-vector(length=p+1);freq[1]<-0
  lower<-matrix(0,nrow=(p+1),ncol=p)
  upper<-matrix(0,nrow=(p+1),ncol=p)
  for(i in 0:p)##########i is the length of MCI
  {
    cap<-vector(length=p-i+1);cap[1]<-0
    for(j in 0:(p-i))##########j is the length of lowerbound
    {
      if(j==0 && i==0){
        lowtest<-rep(0,p)
        upptest<-rep(0,p)
      }else{
        if(j==0 && i!=0){
          lowtest<-rep(0,p)
          upptest<-rep(0,p)
          upptest[order[1:i]]<-1
        }else{
          lowtest<-rep(0,p)
          upptest<-rep(0,p)
          lowtest[order[1:j]]<-1
          upptest[order[1:(i+j)]]<-1
        }
      }
      for(m in 1:r){
        if(all(all(lowtest<=var.matrix[m,]),all(var.matrix[m,]<=upptest))) cap[j+1]<-cap[j+1]+1
      }
    }
    freq[i+1]<-max(cap)/r
    maxlocation<-which.max(cap)
    if(i==0 && maxlocation==1)
    {
      lower[i+1,]<-rep(0,p)
      upper[i+1,]<-rep(0,p)
    }else{
      if(maxlocation==1 && i!=0){
        lower[i+1,]<-rep(0,p)
        upper[i+1,order[1:i]]<-1
      }else{
        lower[i+1,order[1:(maxlocation-1)]]<-1
        upper[i+1,order[1:(maxlocation-1+i)]]<-1
      }
    }
  }
  
  result<-list(freq=freq,lower=lower,upper=upper)
  return(result)
}

# Get bootstrap models under different methods
getBootmodel<-function(data_total,p,r,size,cutoff)
{
  # Boostrap
  var_adaptivelasso<-matrix(0,nrow=r,ncol=p)
  var_lasso<-matrix(0,nrow=r,ncol=p)
  var_mcp<-matrix(0,nrow=r,ncol=p)
  var_scad<-matrix(0,nrow=r,ncol=p)
  var_screen<-matrix(0,nrow=r,ncol=p)

  for(j in 1:r) {

    ind=sample(1:nrow(data_total),nrow(data_total),replace=T)
    boot.data<-data_total[ind,]
    ##################variable selection method: Adaptive Lasso
    adalasso.boot<-adalasso(X=as.matrix(boot.data[,1:p]),y=as.numeric(boot.data$y),k=10)
    var_adaptivelasso[j,]<-full.var%in%full.var[adalasso.boot$coefficients.adalasso!=0]
    ###################variable selection method:lasso
    opt.lambda<-cv.glmnet(x=as.matrix(boot.data[,1:p]),y=as.numeric(boot.data$y),alpha=1)$lambda.min
    lasso.fit<-glmnet(x=as.matrix(boot.data[,1:p]),y=as.numeric(boot.data$y),family='gaussian',alpha=1)
    betalasso<-coef(lasso.fit,s=opt.lambda)[,1][-1]
    var_lasso[j,]<-full.var%in%names(betalasso)[betalasso!=0]
    ##################variable selection method: MCP
    mcp.fit<-cv.ncvreg(X=as.matrix(boot.data[,1:p]),y=as.numeric(boot.data$y),penalty="MCP",max.iter=1000000)
    mcp.fit2<-mcp.fit$fit
    betamcp<-mcp.fit2$beta[,mcp.fit$min]
    betamcp<-betamcp[2:(p+1)]
    var_mcp[j,]<-full.var%in%names(betamcp)[which(betamcp!=0)]
    ##################variable selection method: SCAD
    scad.fit<-cv.ncvreg(X=as.matrix(boot.data[,1:p]),y=as.numeric(boot.data$y),penalty="SCAD",max.iter=1000000)
    scad.fit2<-scad.fit$fit
    betascad<-scad.fit2$beta[,scad.fit$min]
    betascad<-betascad[2:(p+1)]
    var_scad[j,]<-full.var%in%names(betascad)[which(betascad!=0)]
    ##################variable selection method: Screening
    pvalue.screen.boot<-c()
    for(i in 1:p){
      screen.olm.boot<-lm(as.numeric(boot.data$y)~boot.data[,i],data=boot.data)
      pvalue.screen.boot[i]<-summary(screen.olm.boot)$coefficients[2,4]
    }
    var_screen[j,]<-full.var%in%full.var[which(pvalue.screen.boot<=cutoff)]
  }

  var.01<-list(var_adaptivelasso=var_adaptivelasso, var_lasso=var_lasso, var_mcp=var_mcp, var_scad=var_scad, var_screen=var_screen)
  return(var.01)
}

# Get optimal MCB
getOptimalMCBs<-function(cican, confidence.level){
  fit.index<-which(cican$freq >= confidence.level)
  optimal.mcbs.lower<-cican$lower[min(fit.index),]
  optimal.mcbs.upper<-cican$upper[min(fit.index),]
  optimal.width<-min(fit.index)-1
  mcbresult<-list(width=optimal.width, mcb.lower=optimal.mcbs.lower, mcb.upper=optimal.mcbs.upper)
  return(mcbresult)
}

# Load original data
data_response<-read.table("surv.txt",col.names = c('y','delta'))
data_response<-data_response[2:nrow(data_response),]
data_gene<-read.table("Z.txt")

# Selected top rank genes
topvar<-c('AP1S2','BTD','C10ORF54','CA5BP1','CAPN1','CEBPB','EFNA1','FAM107B','FLRT3','KATNB1','LRRC1','LYRM5','AP1S2.1','MYO18A',
          'NOD1','NPLOC4','PLEKHO2','POLR3GL','RAB27A','SECISBP2L','SGTB','STRADB','SWSAP1','TEP1','TERF1','THOC1','TIGD5','TK2',
          'TMEM54','TMEM106A','TOMM7','TRIM34','YARS2')
y<-data_response['y']
datagene.mcb<-data_gene[,topvar]

# Randomly select some genes
rancova<-67
rsv.ind<-sample(ncol(data_gene)-length(topvar),rancova,replace = F)
data_rangene<-data_gene[,setdiff(names(data_gene),topvar)[rsv.ind]]
whole.data<-data.frame(datagene.mcb,data_rangene,y)

# Bootstrap
r=2000
p<-length(whole.data)-1
size<-nrow(whole.data)
cutoff=0.05
full.var<-colnames(whole.data)[-ncol(whole.data)]
timeboot<-system.time(var.boot.matrix<-getBootmodel(whole.data,p,r,size,cutoff))

# Computing coverage rates
timetotal<-system.time(results<-lapply(var.boot.matrix,function(data)CI(data)))
bcr.adalasso<-results$var_adaptivelasso$freq
bcr.lasso<-results$var_lasso$freq
bcr.mcp<-results$var_mcp$freq
bcr.scad<-results$var_scad$freq
bcr.screen<-results$var_screen$freq

# MUC curve
dev.new(width=4,height=4)
cexnum=1.6
par(mar=c(5,5,2,4),mgp=c(3,1,0))

plot(c(0:p)/p,bcr.adalasso,lty=5,lwd=1.5,cex=1,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='l',ylim=c(0,1),xlab='w/p',ylab='Coverage Rate')
lines(c(0:p)/p,bcr.lasso,lty=3, lwd=1.5,cex=1,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='l', ylim=c(0,1))
lines(c(0:p)/p,bcr.mcp,lty=1, lwd=1.5,cex=1,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='o', pch = 9,ylim=c(0,1))
lines(c(0:p)/p,bcr.scad,lty=1, lwd=1.5,cex=1,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='l',ylim=c(0,1))
lines(c(0:p)/p,bcr.screen,lty=1, lwd=1.5,cex=1,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='o', pch = 13,ylim=c(0,1))
legend('topleft',legend=c('Adaptive Lasso','Lasso','MCP','SCAD','Screening'),col=c(1,1,1,1,1),lwd=rep(1.5,5),pch = c(NA,NA,9,NA,13),lty=c(5,3,1,1,1),text.width = 0.4,cex = 1,pt.cex = 1.5)

# visualization MCB under screening method
confidence.level<-c(0.75,0.95)

# screening Original Dataset
pvalue.screen<-c()
for(i in 1:p){
  screen.olm<-lm(as.numeric(whole.data$y)~whole.data[,i],data=whole.data)
  pvalue.screen[i]<-summary(screen.olm)$coefficients[2,4]
}
screen.ind<-which(pvalue.screen<=cutoff)
var_screen_ori<-full.var%in%full.var[which(pvalue.screen<=cutoff)]

TransBitoInd<-function(modeldata){
  dataout<-c()
  for(i in 1:p){
    if(modeldata[i]==1){
      dataout[i]=i
    }else{
      dataout[i]=0
    }
  }
  return(dataout)
}

mcb.screen.width.75<-getOptimalMCBs(results$var_screen,confidence.level[1])$width
cr.screen.75<-bcr.screen[mcb.screen.width.75+1]
mcb.screen.lower.75<-getOptimalMCBs(results$var_screen,confidence.level[1])$mcb.lower
mcb.screen.upper.75<-getOptimalMCBs(results$var_screen,confidence.level[1])$mcb.upper

mcb.screen.width.95<-getOptimalMCBs(results$var_screen,confidence.level[2])$width
cr.screen.95<-bcr.screen[mcb.screen.width.95+1]
mcb.screen.lower.95<-getOptimalMCBs(results$var_screen,confidence.level[2])$mcb.lower
mcb.screen.upper.95<-getOptimalMCBs(results$var_screen,confidence.level[2])$mcb.upper

ori.screen<-TransBitoInd(var_screen_ori)[which(TransBitoInd(var_screen_ori)!=0)]
mcb.screen.lower.trans.75<-TransBitoInd(mcb.screen.lower.75)[which(TransBitoInd(mcb.screen.lower.75)!=0)]
mcb.screen.upper.trans.75<-TransBitoInd(mcb.screen.upper.75)[which(TransBitoInd(mcb.screen.upper.75)!=0)]
mcb.screen.lower.trans.95<-TransBitoInd(mcb.screen.lower.95)[which(TransBitoInd(mcb.screen.lower.95)!=0)]
mcb.screen.upper.trans.95<-TransBitoInd(mcb.screen.upper.95)[which(TransBitoInd(mcb.screen.upper.95)!=0)]

methods<-c(rep(1.2,length(mcb.screen.lower.trans.75)),rep(1.4,length(ori.screen)),rep(1.6,length(mcb.screen.upper.trans.75)),
           rep(2.2,length(mcb.screen.lower.trans.95)),rep(2.4,length(ori.screen)),rep(2.6,length(mcb.screen.upper.trans.95)))

genes<-c(mcb.screen.lower.trans.75,ori.screen,mcb.screen.upper.trans.75,mcb.screen.lower.trans.95,ori.screen,mcb.screen.upper.trans.95)

legends<-c(rep('LBM-75%',length(mcb.screen.lower.trans.75)),rep('Original Selected Model',length(ori.screen)),rep('UBM-75%',length(mcb.screen.upper.trans.75)),
           rep('LBM-95%',length(mcb.screen.lower.trans.95)),rep('Original Selected Model',length(ori.screen)),rep('UBM-95%',length(mcb.screen.upper.trans.95)))

dataplot<-data.frame(Genes=genes,Methods=methods,Legend=legends)

p1<-ggplot(dataplot, aes(x=Methods, y=Genes, shape=Legend))+geom_point(size=1.5)+labs(x="")+scale_shape_manual(values = c(17,16,15,24,21))

xind<-c(1.4,2.4)
xnew<-c('Screening-75%','Screening-95%')
dindx<-data.frame(xind,xnew)
yind<-seq(1,p)
ynew<-full.var
dindy<-data.frame(yind,ynew)
p2 <- p1 + scale_x_continuous(breaks=dindx$xind, labels = dindx$xnew) + theme(axis.text.x = element_text(size = 8, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))

dev.new(width=4,height=4)
p2 + scale_y_continuous(breaks=dindy$yind, labels = dindy$ynew) + theme(axis.text.y = element_text(size = 4, color = "black", vjust = 0.5, hjust = 0.5)) + theme(panel.grid =element_blank(),panel.background = element_rect(fill = "white", colour = "black", size = 1),
                                                                                                                                                                 legend.key=element_rect(fill='transparent', color='transparent'),legend.title=element_blank(),
                                                                                                                                                                 legend.background = element_rect(fill="white", colour = "black", size=.5))

save.image(file="realres_topgene.RData")