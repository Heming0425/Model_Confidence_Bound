############################
# R code to generate figure 2 in the paper
############################
source("functions.R")
source("VSCS_support_functions.R")

#data:diabetes:lars: 10 predictor 442observasions
library(lars)
data("diabetes")
diabetes<-na.omit(diabetes)
realdata=cbind(diabetes$x,diabetes$y)
size=dim(realdata)[1];p=dim(realdata)[2]-1
dep.var.index=p+1;r=1000;s=1
oriname<-colnames(realdata)
colnames(realdata)[1:(dim(realdata)[2]-1)]=paste("x",1:p,sep="")
colnames(realdata)[dep.var.index]='y'
realdata=data.frame(realdata)
full.var<-paste("x",1:p,sep="")

# fit1<-lasso.adapt.bic2(x=realdata[,1:(dim(realdata)[2]-1)],y=realdata$y)
# variables<-names(fit1$coeff)[(fit1$coeff)!=0]

# fit<-regsubsets(y~.,data=realdata,method="seqrep",nvmax=p)
# var.instances<-names(coef(fit,which.min(summary(fit)$bic)))[-1]

# opt.lambda<-cv.glmnet(x=as.matrix(realdata[,-dep.var.index]),y=realdata[,dep.var.index],alpha=1)$lambda.min
# lasso.fit<-glmnet(x=as.matrix(realdata[,-dep.var.index]),y=realdata[,dep.var.index],family='gaussian',alpha=1)
# variables<-summary(coef(lasso.fit,s=opt.lambda))$i[2:length(summary(coef(lasso.fit,s=opt.lambda))$i)]-1


set.seed(123456)
###function3
inter.union<-function(object){
  j=3;
  inter.sect<-intersect(object[[1]],object[[2]])
  union.sect<-union(object[[1]],object[[2]])
  while(j<=k){
    inter.sect<-intersect(inter.sect,object[[j]])
    union.sect<-union(union.sect,object[[j]])
    j<-j+1
  } 
  return(list(inter<-inter.sect,union<-union.sect))  
}

full.var<-paste("x",1:p,sep="")
BOOT.CI.Lasso<-function(x, dep.var.index, r,s, method){
  var.instances<-vector(mode="list",length=r)
  for(i in 1:s) { 
    for(j in 1:r) { 
       ind=sample(1:nrow(x),nrow(x),replace=T)
       boot.data<-x[ind,]
       if (method == 'stepwise'){
          fit<-regsubsets(y~.,data=boot.data,method="seqrep",nvmax=p)
          var.instances[[j]]<-names(coef(fit,which.min(summary(fit)$bic)))[-1]
       }
       if (method == 'lasso'){
            opt.lambda<-cv.glmnet(x=as.matrix(boot.data[,-dep.var.index]),y=boot.data[,dep.var.index],alpha=1)$lambda.min
            lasso.fit<-glmnet(x=as.matrix(boot.data[,-dep.var.index]),y=boot.data[,dep.var.index],family='gaussian',alpha=1)
            inclusion.index<-summary(coef(lasso.fit,s=opt.lambda))$i[2:length(summary(coef(lasso.fit,s=opt.lambda))$i)]-1
            var.instances[[j]]<-colnames(boot.data[inclusion.index])
       }
       if (method == 'adalasso'){
          fit<-lasso.adapt.bic2(x=boot.data[,1:p],y=boot.data$y)
          var.instances[[j]]<-names(fit$coeff)[(fit$coeff)!=0]
       }
    }
  }
  return(var.instances)
}


var.instances.stepwise <- BOOT.CI.Lasso(realdata,dep.var.index,r,s=1, method = 'stepwise')
var.instances.lasso <- BOOT.CI.Lasso(realdata,dep.var.index,r,s=1, method = 'lasso')
var.instances.adalasso <- BOOT.CI.Lasso(realdata,dep.var.index,r,s=1, method = 'adalasso')
var.01.stepwise<-f01(var.instances.stepwise)
var.01.lasso<-f01(var.instances.lasso)
var.01.adalasso<-f01(var.instances.adalasso)
stepwise <- CI(var.instances.stepwise, var.01.stepwise,p)
lassoresult <- CI(var.instances.lasso, var.01.lasso,p)
adaptivelasso <- CI(var.instances.adalasso, var.01.adalasso,p)



adalasso_var_instance <- var.instances.adalasso
lasso_var_instance <- var.instances.lasso
stepwise_var_instance <- var.instances.stepwise
adalasso_upcap<-vector()
lasso_upcap<-vector()
stepwise_upcap<-vector()

toptup<-system.time(for(k in 1:(p-1))
{
  varmatrix<-var.f(k)
  adalasso_upcap[k] <- f2(varmatrix, adalasso_var_instance)
  lasso_upcap[k] <- f2(varmatrix, lasso_var_instance)
  stepwise_upcap[k] <- f2(varmatrix, stepwise_var_instance)
})

adalasso_cap_res<-cioptimal(adalasso_var_instance, p)
adalasso_cap_res<-cbind(adalasso_cap_res,c(0,adalasso_upcap))
adalasso_cap_res<-apply(adalasso_cap_res,1,max)

lasso_cap_res<-cioptimal(lasso_var_instance, p)
lasso_cap_res<-cbind(lasso_cap_res,c(0,lasso_upcap))
lasso_cap_res<-apply(lasso_cap_res,1,max)

stepwise_cap_res<-cioptimal(stepwise_var_instance, p)
stepwise_cap_res<-cbind(stepwise_cap_res,c(0,stepwise_upcap))
stepwise_cap_res<-apply(stepwise_cap_res,1,max)

cexnum=1.6

par(mar=c(5,5,2,4),mgp=c(3,1,0))
plot(x=c(0:p)/p,y=stepwise$freq,lty=1,lwd=3,col=1,cex=cexnum,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='b', pch = 1,ylim=c(0,1),xlab='w/p',ylab='Coverage Rate')
lines(c(0:p)/p,y = c(stepwise_cap_res,1),lty=1, lwd=3,cex=cexnum,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='b',pch=4, ylim=c(0,1))
lines(c(0:p)/p,y = lassoresult$freq,lty=3, lwd=3,col=1,cex=cexnum,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='b', pch = 1,ylim=c(0,1))
lines(c(0:p)/p,y = c(lasso_cap_res,1),lty=3, lwd=3,cex=cexnum,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='b', pch=4,ylim=c(0,1))
lines(c(0:p)/p,y = adaptivelasso$freq,lty=5, lwd=3,col=1,cex=cexnum,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='b', pch = 1,ylim=c(0,1))
lines(c(0:p)/p,y = c(adalasso_cap_res,1),lty=5, lwd=3,cex=cexnum,cex.axis=2.2,cex.lab=cexnum,cex.main=2.2,xlim=c(0,1),type='b', pch=4,ylim=c(0,1))
#lines(c(0:p)/p,c(0:p)/p,lty=2,lwd=3,col=1,xlim=c(0,1),type='l',ylim=c(0,1))
#lines(plotmatrix[,1],plotmatrix[,3],lty=1,lwd=3,col=2,xlim=c(0,p),type='l',ylim=c(0,1))
legend('bottomright',legend = c('Stepwise Algo1','Stepwise Algo2','Lasso Algo1','Lasso Algo2','Adaptive Lasso Algo1','Adaptive Lasso Algo2'),col=c(1,1,1,1,1,1),lwd=rep(3,6),pch = c(4,1,4,1,4,1),lty=c(1,1,3,3,5,5),text.width = 0.4,cex = 1.5,pt.cex = 1.5)




