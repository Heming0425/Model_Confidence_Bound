###################################
# The function to generate Figure 5 and 6 in the supplementary
# You can change the parameter setting to get different figures
###################################
ptm <- proc.time()
source("functions.R")
set.seed(123456)
##parameters setting
p=50;true.mean=0;true.sd=1;decay.factor=1;sd.epsi=1;rho=0.75;dep.var.index=p+1;r=1000;s=1;df=3;num_true_var=8;var_dis = 'normal'
model_type=1; thrhd=0.05;
full.var<-paste("x",1:p,sep="")

f<-function(sample_size){
  size <- sample_size
  test.data<-Generate.Data(size,p,true.mean,true.sd,decay.factor,sd.epsi,rho,num_true_var, model_type, var_dis)
  var.instances<-RES.BOOT.CI(test.data,dep.var.index,r)
  var.01<-f01(var.instances)###0-1 matrix
  full.var<-colnames(var.01)
  result<-CI(var.instances,var.01,p)
  return(result)
}

result200<-f(200)
# result300<-f(300)
result400<-f(400)
result500<-f(500)
#result1000<-f(1000)
# result3000<-f(3000)
cexnum=2.3
par(mar=c(4.6,4.6,1,1))
plot(c(0:p)/p,result200$freq,type='l',cex=cexnum,ylim=c(0,1),cex.axis=cexnum,cex.lab=cexnum,col=1,lty=1,lwd=3,xlab='w/p',ylab = 'Coverage Rate')
lines(c(0:p)/p,result400$freq,type='l',lty=2,lwd=3)
lines(c(0:p)/p,result500$freq,lty=3,lwd=3)
#lines(c(0:p)/p,result1000$freq,type='l',lty=1,lwd=3,col=3)
legend('bottomright',legend=c("n=200",'n=400',"n=500"),lty=c(1,2,3),text.width = 0.3,lwd=rep(3,3),cex = cexnum,pt.cex = cexnum)

file_name <- paste("asymptotic_analysis","sd", sd.epsi, "rho", rho ,"num_tol", p, "num_true", num_true_var, "decay", decay.factor, "boot_time", r, sep = "_")
save.image(file = paste("../MCB_results/",file_name, ".RData", sep = ""))

proc.time() - ptm
processing_time <- proc.time() - ptm
file_name


