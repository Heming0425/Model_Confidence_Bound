library(parallel)
library(MASS)
library(glmnet)

# Generate Data
Generate.Data.Lasso<-function(size,p,sig.num,sd.epsi,rho)
{
  ########################################################multinominal correlated simulation
  omiga<-matrix(0,nrow=p,ncol=p)
  for(i in 1:p)
  {
    for(j in 1:p)
    {
      omiga[i,j]<-rho^(abs(i-j))
    }
  }
  data<-mvrnorm(n=size,mu=rep(0,p),omiga)
  colnames(data)=paste("x",1:p,sep="")
  u<-rnorm(size, 0, sd.epsi)

  b<-matrix(1,nrow=sig.num,ncol=1)
  y<-data[,1:sig.num]%*%b+u
  colnames(y)=c('y')
  return(data.frame(data,y))
}

# MCBs under different widths
CI<-function(var.matrix)
{
  colsum<-apply(var.matrix,2,sum)
  order<-order(colsum,decreasing = T)
  freq<-vector(length=p+1);freq[1]<-0
  lower<-matrix(0,nrow=(p+1),ncol=p)
  upper<-matrix(0,nrow=(p+1),ncol=p)
  for(i in 0:p)##########i is the length of MCI
  { 
    cap<-vector(length=p-i+1);cap[1]<-0  
    for(j in 0:(p-i))##########j is the length of lowerbound
    {
      if(j==0 && i==0){
        lowtest<-rep(0,p)
        upptest<-rep(0,p)
      }else{
        if(j==0 && i!=0){
          lowtest<-rep(0,p)
          upptest<-rep(0,p)
          upptest[order[1:i]]<-1
        }else{
          lowtest<-rep(0,p)
          upptest<-rep(0,p)
          lowtest[order[1:j]]<-1
          upptest[order[1:(i+j)]]<-1
        }
      }
      for(m in 1:r){
        if(all(all(lowtest<=var.matrix[m,]),all(var.matrix[m,]<=upptest))) cap[j+1]<-cap[j+1]+1
      }
    }  
    freq[i+1]<-max(cap)/r
    maxlocation<-which.max(cap)
    if(i==0 && maxlocation==1)
    {
      lower[i+1,]<-rep(0,p)
      upper[i+1,]<-rep(0,p)
    }else{
      if(maxlocation==1 && i!=0){
        lower[i+1,]<-rep(0,p)
        upper[i+1,order[1:i]]<-1
      }else{
        lower[i+1,order[1:(maxlocation-1)]]<-1
        upper[i+1,order[1:(maxlocation-1+i)]]<-1
      }
    }
  }
 
  result<-list(freq=freq,lower=lower,upper=upper)
  return(result)
}


# Get results
getResults<-function(data_total){

  # Adalasso Original Dataset(specified lambda)
  tau<-1
  lasso.init<-glmnet(as.matrix(data_total[,1:p]),data_total$y)
  first.step.coef<-lasso.init$beta[,which.min(abs(lasso.init$lambda-lmbd))]
  penalty.factor<-abs(first.step.coef+1/sqrt(nrow(data_total)))^(-tau)
  adalasso<-glmnet(as.matrix(data_total[,1:p]),data_total$y,penalty.factor=penalty.factor)
  beta.adalasso<-matrix(unname(adalasso$beta[,which.min(abs(adalasso$lambda-lmbd))]),1,p)
  res.adalasso<-data_total$y-as.matrix(data_total[,1:p])%*%t(beta.adalasso)
  res.adalasso.center<-res.adalasso-mean(res.adalasso)
  constant<-as.matrix(data_total[,1:p])%*%t(beta.adalasso)

  # Residual Boostrap
  var.01<-matrix(0,nrow=r,ncol=p)
  for(j in 1:r) { 
    boot_res<-sample(res.adalasso.center,size,replace=T)
    boot_y<-constant+boot_res
    boot.data<-data.frame(data_total[,1:p],boot_y)
    ##################variable selection method: Adaptive Lasso
    lasso.init.boot<-glmnet(as.matrix(boot.data[,1:p]),boot.data$boot_y)
    first.step.coef.boot<-lasso.init.boot$beta[,which.min(abs(lasso.init.boot$lambda-lmbd))]
    penalty.factor.boot<-abs(first.step.coef.boot+1/sqrt(nrow(data_total)))^(-tau)
    adalasso.boot<-glmnet(as.matrix(boot.data[,1:p]),boot.data$boot_y,penalty.factor=penalty.factor.boot)
    beta.adalasso.boot<-adalasso.boot$beta[,which.min(abs(adalasso.boot$lambda-lmbd))]
    var.01[j,]<-full.var%in%full.var[beta.adalasso.boot!=0]
  }

  # Get optimal MCBs
  getOptimalMCBs<-function(cican, confidence.level){
    fit.index<-which(cican$freq >= confidence.level)
    optimal.mcbs.lower<-cican$lower[min(fit.index),]
    optimal.mcbs.upper<-cican$upper[min(fit.index),]
    optimal.width<-min(fit.index)-1
    result<-list(width=optimal.width, mcb.lower=optimal.mcbs.lower, mcb.upper=optimal.mcbs.upper)
    return(result)
  }

  # Computing results under different confidence level
  confidence.level<-c(seq(0.1,0.95,0.05),0.99)
  opt.width<-c()
  opt.lower<-matrix(0,nrow=length(confidence.level),ncol=p)
  opt.upper<-matrix(0,nrow=length(confidence.level),ncol=p)
  getOptMCB<-vector(length=length(confidence.level),mode='list')
  card.adalasso<-c()
  pen.lower<-c()
  pen.upper<-c()
  truecapture<-c()
  
  for(li in 1:length(confidence.level)){
      getOptMCB[[li]]<-getOptimalMCBs(CI(var.01), confidence.level[li])
      opt.width[li]<-getOptMCB[[li]]$width
      opt.lower[li,]<-getOptMCB[[li]]$mcb.lower
      opt.upper[li,]<-getOptMCB[[li]]$mcb.upper

      # Cardinality
      card.adalasso[li]<-2^(opt.width[li])

      # Score Function
      model.lower.true<-rep(0,p)
      model.lower.true[which(opt.lower[li,1:sig.num]==1)]<-1
      model.upper.true<-rep(0,p)
      model.upper.true[which(opt.upper[li,1:sig.num]==1)]<-1
      pen.lower[li]<-sum(abs(opt.lower[li,]-model.lower.true))
      pen.upper[li]<-sum(abs(true.model-model.upper.true))

      # Identify the true model in MCBs
      if(all(all(opt.lower[li,]<=true.model),all(true.model<=opt.upper[li,]))){
        truecapture[li]<-1
        }else{
        truecapture[li]<-0
        }
  }

  results<-list(optwidth=opt.width, optlower=opt.lower, optupper=opt.upper, 
                truecap=truecapture, penalty.low=pen.lower, penalty.up=pen.upper,
                cardinality=card.adalasso)
  return(results)
}

# Parameter settings
size=100;p=10;sig.num=5;sd.epsi=6;rho=0.25;r=1000;s=500
lmbd=0.5
full.var<-paste("x",1:p,sep="")
whole.data<-vector(length=s,mode='list')
for (i in 1:s)
{
  whole.data[[i]]<-Generate.Data.Lasso(size,p, sig.num, sd.epsi,rho)
}

# True Model
true.model<-rep(0,p)
true.model[1:sig.num]<-1

# Parallel(for Linux)
RNGkind("L'Ecuyer-CMRG")
timetotal<-system.time(results<-mclapply(whole.data,function(data)getResults(data),mc.cores=3))

# Output results
optwidth.matrix<-NULL
truecap.matrix<-NULL
penalty.low.matrix<-NULL
penalty.up.matrix<-NULL
cardinality.matrix<-NULL
for(i in 1:length(results)){
  optwidth.matrix<-rbind(optwidth.matrix,results[[i]]$optwidth)
  truecap.matrix<-rbind(truecap.matrix,results[[i]]$truecap)
  penalty.low.matrix<-rbind(penalty.low.matrix,results[[i]]$penalty.low)
  penalty.up.matrix<-rbind(penalty.up.matrix,results[[i]]$penalty.up)
  cardinality.matrix<-rbind(cardinality.matrix,results[[i]]$cardinality)
}

ave.opt<-apply(optwidth.matrix,2,mean)
ave.tcr<-apply(truecap.matrix,2,mean)
ave.penlow<-apply(penalty.low.matrix,2,mean)
ave.penlup<-apply(penalty.up.matrix,2,mean)
ave.card<-apply(cardinality.matrix,2,mean)
table.res<-rbind(ave.opt,ave.penlow,ave.penlup,ave.card,ave.tcr)

save.image("scoresim.RData")









